#ifndef IRSSI_IRC_NOTIFYLIST_NOTIFY_SETUP_H
#define IRSSI_IRC_NOTIFYLIST_NOTIFY_SETUP_H

void notifylist_add_config(NOTIFYLIST_REC *rec);
void notifylist_remove_config(NOTIFYLIST_REC *rec);

void notifylist_read_config(void);

#endif
